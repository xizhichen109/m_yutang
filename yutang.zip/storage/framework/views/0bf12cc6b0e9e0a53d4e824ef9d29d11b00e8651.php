<?php $__env->startSection('content'); ?>
    <div class="container venue_list">
        <div class="row">

            <ul class="type_nav">
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="/venue/type/<?php echo e($type->id); ?>"><?php echo e($type->name); ?></a> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-9">

                <?php $__currentLoopData = $venues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="venue_item">
                        <div class="pic"><img src="/images/venue_icon.jpg" class="img-responsive img-rounded"></div>
                        <div class="txt">
                            <h3><a href="/venue/detail/<?php echo e($venue->id); ?>"><?php echo e($venue->name); ?></a></h3>
                            <p><?php echo e($venue->des); ?></p>
                            <p><?php echo e($venue->created_at); ?> &nbsp; &nbsp;
                            <?php if($venue->isfollowed()): ?>
                                <a href="/venue/unfollow/<?php echo e($venue->id); ?>" > 取消关注</a>
                            <?php else: ?>
                                <a href="/venue/follow/<?php echo e($venue->id); ?>" > 关注</a>
                            <?php endif; ?>
                            </p>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php echo e($venues -> links()); ?>



            </div>
            <div class="col-md-3"><h3>推荐场馆</h3></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>