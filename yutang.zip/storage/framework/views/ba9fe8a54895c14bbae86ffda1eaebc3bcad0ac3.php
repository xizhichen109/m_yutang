<?php $__env->startSection('content'); ?>
    <div class="container venue_create">
        <div class="row">
            <div class="col-md-2">
               <sidebar></sidebar>
            </div>
            <div class="col-md-10">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        我的场馆
                    </div>
                    <div class="panel-body">
                       <table class="table table-striped table-bordered">
                           <tr>
                               <th>id</th>
                               <th>场馆名称</th>
                               <th>创建日期</th>
                               <th>状态</th>
                               <th>操作</th>
                           </tr>
                           <?php $__currentLoopData = $venues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                               <td><?php echo e($venue->id); ?></td>
                               <td><?php echo e($venue->name); ?></td>
                               <td><?php echo e($venue->created_at); ?></td>
                               <td><?php echo e($venue->state); ?></td>
                               <td>
                                   <a href="/venue/edit/<?php echo e($venue->id); ?>">修改</a>
                                   <a href="/venue/delete/<?php echo e($venue->id); ?>">删除</a>
                                   <a href="/price/set/<?php echo e($venue->id); ?>">价格</a>

                               </td>
                           </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </table>
                    </div>
                </div>



            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>