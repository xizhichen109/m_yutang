<?php $__env->startSection('content'); ?>
    <div class="container venue_detail">
        <div class="row">
            <ul class="type_nav">
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="/venue/type/<?php echo e($type->id); ?>"><?php echo e($type->name); ?></a> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-5">
              <img src="/images/ymq.jpg">
            </div>
            <div class="col-md-7">
                <h3 class="venue_title"><?php echo e($venue->name); ?></h3>
                <p>地址: <?php echo e($venue->address); ?></p>
                <p>类型: <?php echo e($venue->type->name); ?></p>
                <p>电话: <?php echo e($venue->tel); ?></p>
                <p>场馆简介:<br> <?php echo e($venue->des); ?></p>
            </div>
        </div>
        <div class="row order_wrap">
            <div class="col-md-9">
                <div class="order_header">
                    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <dl <?php if($key==0): ?> class="active" <?php endif; ?>>
                            <dt><?php echo e($date['date']); ?></dt>
                            <dd><?php echo e($date['week']); ?></dd>
                        </dl>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="order_body">

                    <?php $__currentLoopData = $date_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="day_list <?php if($date == $today): ?> show <?php endif; ?>">
                                 <h3><?php echo e($date); ?></h3>
                                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field_no=>$prices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <dl>
                                    <dt>场地编号:<?php echo e($field_no); ?></dt>
                                    <dd>
                                        <ul>
                                            <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time=>$price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li data-time="<?php echo e($time); ?>" data-field_no="<?php echo e($field_no); ?>"><?php echo e($price); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </dd>
                                </dl>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>

            </div>
            <div class="col-md-3">

                <div class="item_template">
                    <dl class="item">
                        <dt>15:00-16:00</dt>
                        <dd>B3号场</dd>
                    </dl>
                </div>

                <div class="order_detail">
                    <p>场地类型:羽毛球场</p>
                    <p>订单时间:2019-01-05</p>
                    <div class="detail_wrap">
                        <dl class="item">
                            <dt>15:00-16:00</dt>
                            <dd>B3号场</dd>
                        </dl>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>