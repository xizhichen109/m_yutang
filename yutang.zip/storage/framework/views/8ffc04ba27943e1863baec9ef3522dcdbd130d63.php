<?php $__env->startSection('content'); ?>
    <div class="container venue_price pt20">
        <div class="row">
            <div class="col-md-2">
                <sidebar></sidebar>
            </div>
            <div class="col-md-10">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        价格设置
                    </div>
                    <div class="panel-body">
                        <h3><?php echo e($venue->name); ?></h3>

                        <table class="table table-striped table-bordered my_price">
                            <tr>
                                <th>id</th>
                                <th>时段</th>
                                <th>价格</th>
                                <th>操作</th>
                            </tr>

                            <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($price->id); ?></td>
                                    <td><?php echo e($price->time); ?></td>
                                    <td><input type="text" value="<?php echo e($price->price); ?>"></td>
                                    <td><button class="btn btn-info btn-sm save_price">保存</button></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>

                    </div>
                </div>



            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>