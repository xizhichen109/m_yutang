$(function(){

    // 1 价格保存
    $(".save_price").click(function(){

        // 1 获取价格id和价格
        let  $tr = $(this).parents("tr");
        let  $tds = $tr.children();
        let params = {};

        params.id = $tds[0].innerHTML;
        params.price = $tr.find("input").val();


        // 2 设置请求头
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }

        })

        // 3 发起ajax请求
         $.ajax({
              url:"http://www.yutang.test/price/save_price",
              type:"post",
              data:params,
              success:(res)=>{
                   console.log(res);
              }
         })


    });


    // 2 日期切换

    $(".order_header dl").click(function () {

         // 日期切换
         $(".order_header dl").removeClass("active");
         $(this).addClass("active");

         // 当前dl在所有dl中的索引值
         let  index = $(".order_header dl").index(this);

         // 日期列表切换
         $(".day_list").removeClass("show");
         $(".day_list").eq(index).addClass("show");

    })


    // 3 场地预定
    $(".day_list li").click(function () {

        $(this).addClass("selected");

        $time = $(this).attr("data-time");
        $field_no = $(this).attr("data-field_no");

        // 创建item对象
        let item = $(".item_template").html();
        let $item = $(item);

        // 对item对象进行数据组装
        $item.find("dt").html($time+":00");
        $item.find("dd").html("B"+$field_no+"号场地");

        // 追加到订单容器
        $item.appendTo(".detail_wrap");

        
    });



})