<template>
    <ul class="list-group">
        <li class="list-group-item"><a href="/venue/create">创建场馆</a> </li>
        <li class="list-group-item"><a href="/venue/my_venues">我的场馆</a> </li>
        <li class="list-group-item"><a href="/venue/my_follows">我的关注</a> </li>
        <li class="list-group-item"><a href="/user/set_icon">设置头像</a> </li>
        <li class="list-group-item"><a href="/user/reset_pass">重置密码</a> </li>
        <li class="list-group-item"><a href="/logout">退出登录</a> </li>
    </ul>
</template>

<script>
    export default {
        name: "Aside"
    }
</script>

<style scoped>

</style>