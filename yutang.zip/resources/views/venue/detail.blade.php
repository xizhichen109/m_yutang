@extends('layouts.app')

@section('content')
    <div class="container venue_detail">
        <div class="row">
            <ul class="type_nav">
                @foreach($types as $type)
                    <li><a href="/venue/type/{{$type->id}}">{{$type->name}}</a> </li>
                @endforeach
            </ul>
        </div>
        <div class="row">
            <div class="col-md-5">
              <img src="/images/ymq.jpg">
            </div>
            <div class="col-md-7">
                <h3 class="venue_title">{{$venue->name}}</h3>
                <p>地址: {{$venue->address }}</p>
                <p>类型: {{$venue->type->name}}</p>
                <p>电话: {{ $venue->tel }}</p>
                <p>场馆简介:<br> {{$venue->des}}</p>
            </div>
        </div>
        <div class="row order_wrap">
            <div class="col-md-9">
                <div class="order_header">
                    @foreach($dates as $key=>$date)
                        <dl @if($key==0) class="active" @endif>
                            <dt>{{$date['date']}}</dt>
                            <dd>{{$date['week']}}</dd>
                        </dl>
                    @endforeach
                </div>
                <div class="order_body">

                    @foreach($date_list as $date=>$list)

                        <div class="day_list @if($date == $today) show @endif">
                                 <h3>{{$date}}</h3>
                                @foreach($list as $field_no=>$prices)
                                <dl>
                                    <dt>场地编号:{{$field_no}}</dt>
                                    <dd>
                                        <ul>
                                            @foreach($prices as $time=>$price)
                                            <li data-time="{{$time}}" data-field_no="{{$field_no}}">{{$price}}</li>
                                            @endforeach
                                        </ul>
                                    </dd>
                                </dl>
                                @endforeach

                        </div>

                    @endforeach


                </div>

            </div>
            <div class="col-md-3">

                <div class="item_template">
                    <dl class="item">
                        <dt>15:00-16:00</dt>
                        <dd>B3号场</dd>
                    </dl>
                </div>

                <div class="order_detail">
                    <p>场地类型:羽毛球场</p>
                    <p>订单时间:2019-01-05</p>
                    <div class="detail_wrap">
                        <dl class="item">
                            <dt>15:00-16:00</dt>
                            <dd>B3号场</dd>
                        </dl>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

