<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Venue_user extends Model
{
    //管理的表
    protected  $table="user_venue";  // venue_users

    // 每个模型 都会操作一个表  User  users   Venue venues

    // Venue_user venue_users




}
